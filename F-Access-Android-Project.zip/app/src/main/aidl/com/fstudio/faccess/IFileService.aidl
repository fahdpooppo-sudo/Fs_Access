package com.fstudio.faccess;

interface IFileService {
    void destroy() = 16777114;
    String[] list(String path);
    boolean delete(String path);
    boolean rename(String path, String newName);
    boolean mkdir(String path, String name);
    boolean copy(String source, String destinationDirectory);
    String getIdentity();
}
