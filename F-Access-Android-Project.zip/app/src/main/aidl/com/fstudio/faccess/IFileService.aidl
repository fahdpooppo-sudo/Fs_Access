package com.fstudio.faccess;

interface IFileService {
    void destroy() = 16777114;
    String[] list(String path) = 1;
    boolean delete(String path) = 2;
    boolean rename(String path, String newName) = 3;
    boolean mkdir(String path, String name) = 4;
    boolean copy(String source, String destinationDirectory) = 5;
    String getIdentity() = 6;
}
