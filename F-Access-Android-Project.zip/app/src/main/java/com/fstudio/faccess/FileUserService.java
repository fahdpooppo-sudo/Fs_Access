package com.fstudio.faccess;

import android.os.RemoteException;
import android.system.Os;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class FileUserService extends IFileService.Stub {
    private static final String STORAGE = "/storage/emulated/0";

    private File checked(String raw) throws IOException {
        if (raw == null || raw.trim().isEmpty()) throw new IOException("مسار فارغ");
        File f = new File(raw).getCanonicalFile();
        File base = new File(STORAGE).getCanonicalFile();
        String p = f.getPath();
        if (!p.equals(base.getPath()) && !p.startsWith(base.getPath() + File.separator)) {
            throw new IOException("المسار خارج مساحة التخزين المشتركة");
        }
        return f;
    }

    @Override
    public String[] list(String path) throws RemoteException {
        try {
            File dir = checked(path);
            if (!dir.isDirectory()) return new String[0];
            File[] entries = dir.listFiles();
            if (entries == null) return new String[0];
            Arrays.sort(entries, Comparator.comparing((File f) -> !f.isDirectory())
                    .thenComparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            List<String> out = new ArrayList<>();
            for (File f : entries) {
                out.add((f.isDirectory() ? "D|" : "F|") + f.getName());
            }
            return out.toArray(new String[0]);
        } catch (Exception e) {
            throw new RemoteException(e.getMessage());
        }
    }

    @Override
    public boolean delete(String path) throws RemoteException {
        try { return deleteTree(checked(path)); }
        catch (Exception e) { throw new RemoteException(e.getMessage()); }
    }

    private boolean deleteTree(File f) {
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) {
                if (!deleteTree(child)) return false;
            }
        }
        return f.delete();
    }

    @Override
    public boolean rename(String path, String newName) throws RemoteException {
        try {
            if (newName == null || newName.trim().isEmpty() || newName.contains("/") || newName.contains("\\")) return false;
            File src = checked(path);
            File dst = checked(new File(src.getParentFile(), newName).getPath());
            return src.renameTo(dst);
        } catch (Exception e) { throw new RemoteException(e.getMessage()); }
    }

    @Override
    public boolean mkdir(String path, String name) throws RemoteException {
        try {
            if (name == null || name.trim().isEmpty() || name.contains("/") || name.contains("\\")) return false;
            File dir = checked(path);
            return checked(new File(dir, name).getPath()).mkdir();
        } catch (Exception e) { throw new RemoteException(e.getMessage()); }
    }

    @Override
    public boolean copy(String source, String destinationDirectory) throws RemoteException {
        try {
            File src = checked(source);
            File destDir = checked(destinationDirectory);
            if (!src.exists() || !destDir.isDirectory()) return false;
            File dest = checked(new File(destDir, src.getName()).getPath());
            if (src.equals(dest) || dest.exists()) return false;
            if (src.isDirectory() && dest.getPath().startsWith(src.getPath() + File.separator)) return false;
            return copyTree(src, dest);
        } catch (Exception e) { throw new RemoteException(e.getMessage()); }
    }

    private boolean copyTree(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdir()) return false;
            File[] children = src.listFiles();
            if (children == null) return true;
            for (File child : children) {
                if (!copyTree(child, new File(dst, child.getName()))) return false;
            }
            return true;
        }
        try (FileInputStream in = new FileInputStream(src);
             FileOutputStream out = new FileOutputStream(dst)) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            out.getFD().sync();
            return true;
        }
    }

    @Override
    public String getIdentity() throws RemoteException {
        return "UID=" + Os.getuid() + " | PID=" + Os.getpid();
    }

    @Override
    public void destroy() {
        System.exit(0);
    }
}
