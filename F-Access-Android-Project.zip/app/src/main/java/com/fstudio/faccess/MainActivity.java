package com.fstudio.faccess;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSION = 410;
    private IFileService remote;
    private boolean bound = false;
    private String currentPath = "/storage/emulated/0";
    private String selectedPath = null;

    private TextView status, pathView, identityView;
    private LinearLayout rows;
    private Button connectButton;

    private final Shizuku.OnBinderReceivedListener binderReceived = this::refreshStatus;
    private final Shizuku.OnBinderDeadListener binderDead = () -> runOnUiThread(() -> setStatus("خدمة Shizuku غير متصلة"));
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code == REQUEST_PERMISSION && result == PackageManager.PERMISSION_GRANTED) {
            connectToService();
        } else {
            setStatus("لم يتم منح الإذن");
        }
    };

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            remote = IFileService.Stub.asInterface(service);
            bound = true;
            runOnUiThread(() -> {
                setStatus("متصل بصلاحيات Shizuku");
                loadDirectory(currentPath);
                loadIdentity();
            });
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            remote = null;
            bound = false;
            runOnUiThread(() -> setStatus("انقطع اتصال الخدمة"));
        }
    };

    private final Shizuku.UserServiceArgs serviceArgs =
            new Shizuku.UserServiceArgs(new ComponentName(BuildConfig.APPLICATION_ID, FileUserService.class.getName()))
                    .daemon(false)
                    .processNameSuffix("fileservice")
                    .debuggable(BuildConfig.DEBUG)
                    .version(BuildConfig.VERSION_CODE);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        Shizuku.addBinderReceivedListenerSticky(binderReceived);
        Shizuku.addBinderDeadListener(binderDead);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        refreshStatus();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeBinderReceivedListener(binderReceived);
        Shizuku.removeBinderDeadListener(binderDead);
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        if (bound) {
            try { Shizuku.unbindUserService(serviceArgs, serviceConnection, true); } catch (Throwable ignored) {}
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(12, 14, 18));
        scroll.addView(root);

        TextView title = text("F-ACCESS", 27, Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);
        TextView subtitle = text("مدير ملفات بصلاحيات Shizuku", 14, Color.LTGRAY);
        root.addView(subtitle);

        status = text("جاري فحص الاتصال…", 14, Color.rgb(255, 190, 90));
        status.setPadding(0, dp(16), 0, dp(8));
        root.addView(status);

        connectButton = button("الاتصال / طلب الصلاحية");
        connectButton.setOnClickListener(v -> requestAndConnect());
        root.addView(connectButton);

        identityView = text("هوية الخدمة: غير متصل", 12, Color.GRAY);
        root.addView(identityView);

        LinearLayout shortcuts = new LinearLayout(this);
        shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        addButton(shortcuts, "التخزين", () -> loadDirectory("/storage/emulated/0"));
        addButton(shortcuts, "Android/data", () -> loadDirectory("/storage/emulated/0/Android/data"));
        addButton(shortcuts, "Android/obb", () -> loadDirectory("/storage/emulated/0/Android/obb"));
        root.addView(shortcuts);

        pathView = text(currentPath, 13, Color.rgb(120, 210, 255));
        pathView.setPadding(0, dp(15), 0, dp(8));
        root.addView(pathView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        addButton(actions, "رجوع", this::goUp);
        addButton(actions, "مجلد جديد", this::newFolder);
        addButton(actions, "إعادة تسمية", this::renameSelected);
        addButton(actions, "نسخ", this::copySelected);
        addButton(actions, "حذف", this::deleteSelected);
        root.addView(actions);

        rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.setPadding(0, dp(10), 0, 0);
        root.addView(rows);

        setContentView(scroll);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(11);
        b.setAllCaps(false);
        return b;
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        Button b = button(label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1);
        p.setMargins(dp(2), dp(3), dp(2), dp(3));
        parent.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setStatus(String message) {
        if (status != null) status.setText(message);
    }

    private void refreshStatus() {
        runOnUiThread(() -> {
            if (!Shizuku.pingBinder()) {
                setStatus("Shizuku غير مشغّل. افتح تطبيق Shizuku وشغّل الخدمة.");
            } else if (Shizuku.isPreV11()) {
                setStatus("إصدار Shizuku أقدم من المطلوب. حدّثه.");
            } else {
                setStatus("Shizuku متصل. اضغط زر الاتصال لمنح الإذن.");
            }
        });
    }

    private void requestAndConnect() {
        if (!Shizuku.pingBinder()) {
            setStatus("شغّل Shizuku أولاً ثم ارجع هنا.");
            return;
        }
        try {
            if (Shizuku.isPreV11()) {
                setStatus("هذا التطبيق يحتاج Shizuku API 11 أو أحدث.");
                return;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                connectToService();
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                setStatus("الإذن مرفوض. راجع أذونات التطبيق داخل Shizuku.");
            } else {
                Shizuku.requestPermission(REQUEST_PERMISSION);
            }
        } catch (Throwable e) {
            setStatus("تعذر طلب الإذن: " + e.getMessage());
        }
    }

    private void connectToService() {
        try {
            if (!Shizuku.pingBinder()) {
                setStatus("الخدمة غير متاحة");
                return;
            }
            Shizuku.bindUserService(serviceArgs, serviceConnection);
            setStatus("جارٍ تشغيل خدمة الملفات…");
        } catch (Throwable e) {
            setStatus("فشل الاتصال: " + e.getMessage());
        }
    }

    private void loadIdentity() {
        new Thread(() -> {
            try {
                String id = remote.getIdentity();
                runOnUiThread(() -> identityView.setText("هوية الخدمة: " + id));
            } catch (Exception e) {
                runOnUiThread(() -> identityView.setText("تعذر قراءة الهوية"));
            }
        }).start();
    }

    private void loadDirectory(String path) {
        if (remote == null) {
            currentPath = path;
            pathView.setText(path);
            setStatus("اتصل بالخدمة أولاً");
            return;
        }
        currentPath = path;
        selectedPath = null;
        pathView.setText(path);
        setStatus("جارٍ تحميل الملفات…");
        new Thread(() -> {
            try {
                String[] entries = remote.list(path);
                runOnUiThread(() -> showEntries(entries));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    rows.removeAllViews();
                    setStatus("تعذر فتح المجلد: " + e.getMessage());
                });
            }
        }).start();
    }

    private void showEntries(String[] entries) {
        rows.removeAllViews();
        setStatus("عدد العناصر: " + entries.length);
        if (entries.length == 0) {
            rows.addView(text("المجلد فارغ أو لا يمكن قراءته.", 14, Color.GRAY));
            return;
        }
        for (String entry : entries) {
            boolean dir = entry.startsWith("D|");
            String name = entry.substring(2);
            TextView item = text((dir ? "📁  " : "📄  ") + name, 15, Color.WHITE);
            item.setPadding(dp(12), dp(13), dp(8), dp(13));
            item.setBackgroundColor(Color.rgb(24, 28, 35));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, dp(5));
            rows.addView(item, lp);
            String full = currentPath + (currentPath.endsWith("/") ? "" : "/") + name;
            item.setOnClickListener(v -> {
                selectedPath = full;
                setStatus("تم تحديد: " + name);
                for (int i = 0; i < rows.getChildCount(); i++) rows.getChildAt(i).setAlpha(0.72f);
                item.setAlpha(1f);
            });
            item.setOnLongClickListener(v -> {
                if (dir) loadDirectory(full);
                else {
                    selectedPath = full;
                    setStatus("تم تحديد الملف: " + name);
                }
                return true;
            });
            if (dir) item.setOnClickListener(v -> loadDirectory(full));
            item.setOnLongClickListener(v -> {
                selectedPath = full;
                setStatus("تم تحديد: " + name + " | استخدم أزرار العمليات");
                return true;
            });
        }
    }

    private void goUp() {
        if (currentPath.equals("/storage/emulated/0")) return;
        int cut = currentPath.lastIndexOf('/');
        String parent = cut <= "/storage/emulated/0".length() ? "/storage/emulated/0" : currentPath.substring(0, cut);
        loadDirectory(parent);
    }

    private void runOperation(String success, RemoteCall call) {
        if (remote == null) { setStatus("اتصل بالخدمة أولاً"); return; }
        setStatus("جارٍ تنفيذ العملية…");
        new Thread(() -> {
            try {
                boolean ok = call.run();
                runOnUiThread(() -> {
                    setStatus(ok ? success : "لم تنجح العملية. قد يكون الوصول محظوراً من النظام.");
                    if (ok) loadDirectory(currentPath);
                });
            } catch (Exception e) {
                runOnUiThread(() -> setStatus("خطأ: " + e.getMessage()));
            }
        }).start();
    }

    private interface RemoteCall { boolean run() throws Exception; }

    private void newFolder() {
        EditText input = new EditText(this);
        input.setHint("اسم المجلد");
        new AlertDialog.Builder(this).setTitle("إنشاء مجلد").setView(input)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إنشاء", (d, w) -> runOperation("تم إنشاء المجلد", () -> remote.mkdir(currentPath, input.getText().toString().trim())))
                .show();
    }

    private void renameSelected() {
        if (selectedPath == null) { setStatus("حدد عنصراً بالضغط المطوّل أولاً"); return; }
        EditText input = new EditText(this);
        input.setText(selectedPath.substring(selectedPath.lastIndexOf('/') + 1));
        new AlertDialog.Builder(this).setTitle("إعادة تسمية").setView(input)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حفظ", (d, w) -> runOperation("تمت إعادة التسمية", () -> remote.rename(selectedPath, input.getText().toString().trim())))
                .show();
    }

    private void copySelected() {
        if (selectedPath == null) { setStatus("حدد عنصراً بالضغط المطوّل أولاً"); return; }
        new AlertDialog.Builder(this).setTitle("نسخ إلى")
                .setMessage("سيتم نسخ العنصر المحدد إلى المجلد الحالي: " + currentPath)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("نسخ", (d, w) -> runOperation("اكتمل النسخ", () -> remote.copy(selectedPath, currentPath)))
                .show();
    }

    private void deleteSelected() {
        if (selectedPath == null) { setStatus("حدد عنصراً بالضغط المطوّل أولاً"); return; }
        new AlertDialog.Builder(this).setTitle("تأكيد الحذف")
                .setMessage("سيتم حذف العنصر نهائياً:\n" + selectedPath)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف نهائياً", (d, w) -> runOperation("تم الحذف", () -> remote.delete(selectedPath)))
                .show();
    }
}
